package com.url.shorterner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UrlShorternerSbApplication {

	public static void main(String[] args) {
		SpringApplication.run(UrlShorternerSbApplication.class, args);
	}

}
