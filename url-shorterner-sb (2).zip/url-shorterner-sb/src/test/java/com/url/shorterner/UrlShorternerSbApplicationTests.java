package com.url.shorterner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UrlShorternerSbApplicationTests {

	@Test
	void contextLoads() {
	}

}
